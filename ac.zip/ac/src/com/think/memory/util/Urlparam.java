package com.think.memory.util;

public class Urlparam  {
	
	String key, value;
	public Urlparam(String key, String value){
		this.key = key;
		this.value = value;
	}
}
